package com.example.carpoolz_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
