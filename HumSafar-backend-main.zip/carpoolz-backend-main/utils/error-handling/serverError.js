module.exports = function () {
  return {
    success: false,
    code: -1,
    message: "Internal server error.",
  };
};
